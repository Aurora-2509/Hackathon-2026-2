import {getCatalogBinding} from '../../../../db';
import {createInference,rankCandidates} from '../../../../lib/ai/inference.mjs';
import model from '../../../../lib/ai/model.json';
const inference=createInference(model);
const labels:Record<string,string>={shirt:'Shirts',pants:'Pants',shoes:'Shoes'};
export async function GET(request:Request){
 try{
  const p=new URL(request.url).searchParams,category=p.get('category')||'',description=(p.get('description')||'').trim().slice(0,250);
  if(!Object.hasOwn(labels,category))return Response.json({error:'Choose a shirt, pants or shoes.'},{status:400});
  if(!description)return Response.json({error:'Describe your starting item so the AI can compare it with your closet.'},{status:400});
  const db=getCatalogBinding();const details=[p.get('color'),p.get('style')].filter((v):v is string=>!!v&&v!=='unknown'&&!description.toLowerCase().includes(v.toLowerCase())).map(v=>v.slice(0,50));let anchor={name:[description,...details].join(' '),category:labels[category]};
  const anchorId=p.get('anchor_id');
  if(anchorId){const existing=await db.prepare('SELECT name,original_category,category FROM clothing_items WHERE id=?').bind(anchorId.slice(0,200)).first<{name:string;original_category:string;category:string}>();if(existing&&existing.category===category&&existing.name===description)anchor={name:existing.name,category:existing.original_category}}
  const groups=[];
  for(const target of Object.keys(labels).filter(c=>c!==category)){
   const count=await db.prepare('SELECT COUNT(*) as total FROM clothing_items WHERE category=?').bind(target).first<{total:number}>();
   // Same bounded candidate approach as the original generator: up to 80 per category.
   const result=await db.prepare('SELECT * FROM clothing_items WHERE category=? ORDER BY RANDOM() LIMIT 80').bind(target).all<Record<string,any>>();
   const items=rankCandidates(inference,anchor,result.results).slice(0,3);
   groups.push({category:target,total:count?.total||0,searched:result.results.length,items});
  }
  return Response.json({groups,model:{name:'Polyvore text compatibility MLP',parameters:3137,checkpoint_sha256:model.source_checkpoint_sha256,candidate_limit:80,score_type:'uncalibrated ranking score',input:'item description and original category'}},{headers:{'Cache-Control':'no-store'}});
 }catch(e){console.error(e);return Response.json({error:'AI recommendations are temporarily unavailable. Please try again.'},{status:503})}
}
